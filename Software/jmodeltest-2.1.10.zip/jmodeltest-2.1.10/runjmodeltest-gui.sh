java -jar jModelTest.jar
